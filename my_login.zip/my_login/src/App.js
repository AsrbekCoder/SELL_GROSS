import { Home } from "./Pages/index";
import { Route, Routes } from "react-router-dom";

import "flickity/dist/flickity.min.css";
import "react-phone-number-input/style.css";
import EmptyHeart from "./Errors/EmptyHeart";
import { Cabinet, Footer, Header } from "./components";
import Register from "./components/Auth/Register";
import Login from "./components/Auth/Login";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { getMe } from "./redux/slices/authLogin";

const App = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getMe());
  }, [dispatch]);

  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/cabinet" element={<Cabinet />} />
        <Route path="*" element={<EmptyHeart />} />
      </Routes>
      <Footer />
    </>
  );
};

export default App;
