import React from "react";

const EmptyHeart = () => {
  return (
    <div className="error_box">
      <img src="../404.png" alt="" />
    </div>
  );
};

export default EmptyHeart;
