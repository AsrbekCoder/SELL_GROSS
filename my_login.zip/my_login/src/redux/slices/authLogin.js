import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "../../axios";

const initialState = {
  data: null,
  status: false,
};

export const loginAuth = createAsyncThunk(
  "auth/login",
  async (obj, { rejectWithValue }) => {
    try {
      const { data } = await axios.post("api/login", obj);

      return data;
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);
export const getMe = createAsyncThunk(
  "auth/me",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await axios.get("api/me");
      return data;
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);

const authLogin = createSlice({
  name: "authLogin",
  initialState,
  reducers: {
    logout: (state) => {
      state.data = "null";
      state.status = false;
    },
  },

  extraReducers: {
    [loginAuth.pending]: (state) => {
      state.data = null;
      state.status = "loading";
    },
    [loginAuth.fulfilled]: (state, action) => {
      state.data = action.payload;
      state.status = true;
    },
    [loginAuth.rejected]: (state, action) => {
      state.data = action.payload;
      state.status = false;
    },
    [getMe.pending]: (state) => {
      state.data = null;
      state.status = "loading";
    },
    [getMe.fulfilled]: (state, action) => {
      state.data = action.payload;
      state.status = true;
    },
    [getMe.rejected]: (state, action) => {
      state.data = action.payload;
      state.status = false;
    },
  },
});

export const isLoginTrue = (status) => (status === true ? true : false);

export const { logout } = authLogin.actions;
export default authLogin.reducer;
