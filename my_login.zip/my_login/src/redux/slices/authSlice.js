import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "../../axios";

const initialState = {
  data: null,
  status: false,
};

export const authRegister = createAsyncThunk("auth/register", async (obj) => {
  const { data } = await axios.post("api/register", obj);
  return data;
});

const authSlice = createSlice({
  name: "auth",
  initialState,

  extraReducers: {
    [authRegister.pending]: (state) => {
      state.status = "loading";
    },
    [authRegister.fulfilled]: (state, action) => {
      state.data = action.payload;
      state.status = "loading";
    },
    [authRegister.rejected]: (state) => {
      state.data = null;
      state.status = false;
    },
  },
});

export default authSlice.reducer;
