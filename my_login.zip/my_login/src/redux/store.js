import { configureStore } from "@reduxjs/toolkit";
import authRegister from "./slices/authSlice";
import authLogin from "./slices/authLogin";

const store = configureStore({
  reducer: {
    register: authRegister,
    login: authLogin,
  },
});

export default store;
