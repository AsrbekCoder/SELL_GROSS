import React from "react";

const DropDowns = ({ categBoolean }) => {
  return (
    <div className={!categBoolean ? "drop_down" : "drop_down active"}>
      <div className="drop_left">
        <ul className="drop_menu">
          <li className="drop_item active">Lorem</li>
          <li className="drop_item">Lorem</li>
          <li className="drop_item">Lorem</li>
          <li className="drop_item">Lorem</li>
          <li className="drop_item">Lorem</li>
          <li className="drop_item">Lorem</li>
        </ul>
      </div>
      <div className="drop_right">
        <ul className="drop_item_menu">
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
          <li className="drop_item_menu_items">Good</li>
        </ul>
      </div>
    </div>
  );
};

export default DropDowns;
