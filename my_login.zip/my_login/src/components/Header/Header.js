import { faUser } from "@fortawesome/free-regular-svg-icons";
import {
  faBars,
  faHeart,
  faSearch,
  faCartShopping,
  faRightToBracket,
  faX,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { useState } from "react";
import { useSelector } from "react-redux";
import { Link, useLocation } from "react-router-dom";
import { isLoginTrue } from "../../redux/slices/authLogin";
import DropDowns from "./DropDowns";

const Header = () => {
  const [categBoolean, setCategBoolean] = useState(false);
  const handleToggle = () => {
    setCategBoolean(() => !categBoolean);
  };

  const { data, status } = useSelector(({ login }) => login);

  const isTrue = isLoginTrue(status);

  const location = useLocation();
  return (
    <header className="header">
      <div className="header_container">
        <div className="header_logo">mini market</div>

        <nav className="navbar_nav">
          <ul className="nav_menu">
            <li className="nav_items">
              <a href="#s" className="nav_link">
                <button className="categoria" onClick={handleToggle}>
                  <FontAwesomeIcon
                    className="i"
                    icon={!categBoolean ? faBars : faX}
                  />
                  Kategoriya
                </button>
              </a>
            </li>
            <li className="nav_items">
              <div className="input_search">
                <input
                  type="text"
                  className="nav_link input_search_input"
                  placeholder="Men qidiryamman..."
                />
                <div className="i">
                  <FontAwesomeIcon icon={faSearch} />
                </div>
              </div>
            </li>
            <li className="nav_items">
              <Link to="/saved" className="nav_link">
                <div className="number_alt">
                  <FontAwesomeIcon className="i" icon={faHeart} />
                  <span>0</span>
                </div>
                <h4>Istaklar</h4>
              </Link>
            </li>
            <li className="nav_items">
              <Link to="/shopping-cart" className="nav_link">
                <div className="number_alt">
                  <FontAwesomeIcon className="i" icon={faCartShopping} />
                  <span>0</span>
                </div>
                <h4>Savat</h4>
              </Link>
            </li>

            {!isTrue ? (
              location.pathname !== "/login" &&
              location.pathname !== "/register" ? (
                <li className="nav_items">
                  <Link to="/login" className="nav_link">
                    <div className="number_alt">
                      <FontAwesomeIcon className="i" icon={faRightToBracket} />
                    </div>
                    <h4>Kirish</h4>
                  </Link>
                </li>
              ) : null
            ) : (
              <li>
                <Link to="/cabinet" className="nav_link">
                  <div className="number_alt">
                    <FontAwesomeIcon className="i" icon={faUser} />
                  </div>
                  <h4>
                    {data.firstname} {data.secondname}
                  </h4>
                </Link>
              </li>
            )}
          </ul>
        </nav>
      </div>
      <DropDowns categBoolean={categBoolean} />
    </header>
  );
};

export default Header;
