import Header from "./Header/Header";
import Footer from "./Footer/Footer";
import Cabinet from "./Cabinet/Cabinet";

export { Header, Footer, Cabinet };
