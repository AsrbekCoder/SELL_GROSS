import Flickity from "flickity";
import React from "react";
import { useEffect } from "react";
import apiMock from "../../Json/brand.json";

const SlidesCategories = () => {
  useEffect(() => {
    new Flickity(".carousel1", {
      groupCells: "100%",
      autoPlay: 5000,
    });
  }, []);

  return (
    <main className="cotegories">
      <div className="categoria_container">
        <div className="main_header">
          <h1>Kategoriya</h1>
        </div>
        <br />
        <div className="carousel1 carousel_data">
          {apiMock.map((item, idx) => (
            <div className="carousel-cell cell_categories" key={idx}>
              <div className="cell_content">
                <div className="cell_content_img">
                  <img src={item.brandImgUrl} alt="" />
                </div>
                <h2>{item.brandTypeName}</h2>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};

export default SlidesCategories;
