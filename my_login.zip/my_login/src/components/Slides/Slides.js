import Flickity from "flickity";
import React from "react";
import { useEffect } from "react";

const Slides = () => {
  useEffect(() => {
    new Flickity(".carousel", {
      wrapAround: "100%",
      autoPlay: 4000,
    });
  }, []);

  return (
    <main className="slider_page">
      <div className="carousel">
        <div className="carousel-cell cell_header">
          <img
            src="https://ikarvon.uz/storage/banners/April2022/LF7Yw3AHS9YAFiIv4plh.webp"
            alt=""
          />
        </div>
        <div className="carousel-cell cell_header">
          <img
            src="https://ikarvon.uz/storage/banners/April2022/LF7Yw3AHS9YAFiIv4plh.webp"
            alt=""
          />
        </div>
        <div className="carousel-cell cell_header">
          <img
            src="https://ikarvon.uz/storage/banners/March2022/NUEJrpRd7xn0xl3kRZhH.webp"
            alt=""
          />
        </div>
      </div>
    </main>
  );
};

export default Slides;
