import React from "react";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import PhoneInput from "react-phone-number-input";
import { loginSchema } from "../../utils/Schema";
import { Link, Navigate } from "react-router-dom";
import { ErrorMessage } from "@hookform/error-message";
import { useDispatch, useSelector } from "react-redux";
import { isLoginTrue, loginAuth } from "../../redux/slices/authLogin";

const Login = () => {
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(loginSchema),
  });

  const submit = async (obj) => {
    const data = await dispatch(loginAuth(obj));

    if (data.payload?.token) {
      return localStorage.setItem("token", data.payload?.token);
    }
  };

  const { status } = useSelector(({ login }) => login);

  const isTrue = isLoginTrue(status);

  if (isTrue) {
    return <Navigate to="/" />;
  }

  return (
    <div className="auth_box">
      <div className="auth_box_main login">
        <form className="auth_inputs" onSubmit={handleSubmit(submit)}>
          <h1>Kirish</h1>
          <Controller
            name="phonenumber"
            control={control}
            rules={{ required: true }}
            render={({ field: { onChange, value } }) => (
              <PhoneInput
                value={value}
                onChange={onChange}
                defaultCountry="UZ"
                id="phone-input"
                international
                className="input"
              />
            )}
          />
          <ErrorMessage
            errors={errors}
            name="phonenumber"
            render={({ message }) => <p>{message}</p>}
          />
          <input
            type="password"
            className="input"
            placeholder="Parol"
            {...register("password")}
          />
          <ErrorMessage
            errors={errors}
            name="password"
            render={({ message }) => <p>{message}</p>}
          />
          <input type="submit" value={"Yuborish"} className="btn" />
        </form>
        <div className="auth_left">
          <Link to="/register">
            <button className="btn">Ro'yxatdan o'tish</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
