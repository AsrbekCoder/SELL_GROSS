import React from "react";
import { Controller, useForm } from "react-hook-form";

import { yupResolver } from "@hookform/resolvers/yup";
import PhoneInput from "react-phone-number-input";

import { registerSchema } from "../../utils/Schema";
import { Link } from "react-router-dom";
import { ErrorMessage } from "@hookform/error-message";
import { useDispatch } from "react-redux";
import { authRegister } from "../../redux/slices/authSlice";

const Register = () => {
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(registerSchema),
  });

  const submit = (data) => {
    dispatch(authRegister(data));
    console.log(data);
  };
  return (
    <div className="auth_box">
      {" "}
      <div className="auth_box_main">
        <div className="auth_left">
          <Link to="/login">
            <button className="btn">Kirish</button>
          </Link>
        </div>

        <form className="auth_inputs" onSubmit={handleSubmit(submit)}>
          <h1>Ro'yxatdan o'tish</h1>
          <input
            type="text"
            className="input"
            placeholder="Familiyangiz"
            {...register("firstname")}
          />
          <ErrorMessage
            name="firstname"
            errors={errors}
            render={({ message }) => <p>{message}</p>}
          />
          <input
            type="text"
            className="input"
            placeholder="Ismingiz"
            {...register("secondname")}
          />
          <ErrorMessage
            name="secondname"
            errors={errors}
            render={({ message }) => <p>{message}</p>}
          />
          <Controller
            name="phonenumber"
            control={control}
            rules={{ required: true }}
            render={({ field: { onChange, value } }) => (
              <PhoneInput
                value={value}
                onChange={onChange}
                defaultCountry="UZ"
                id="phone-input"
                international
                className="input"
              />
            )}
          />

          <ErrorMessage
            name="phonenumber"
            errors={errors}
            render={({ message }) => <p>{message}</p>}
          />
          <input
            type="password"
            className="input"
            placeholder="Parol"
            {...register("password")}
          />
          <ErrorMessage
            name="password"
            errors={errors}
            render={({ message }) => <p>{message}</p>}
          />

          <input
            type="password"
            className="input"
            placeholder="Parolni Tasdiqlang"
            {...register("passwordConfirm")}
          />
          <ErrorMessage
            name="passwordConfirm"
            errors={errors}
            render={({ message }) => <p>{message}</p>}
          />
          <input type="submit" value="Yuborish" className="btn" />
        </form>
      </div>
    </div>
  );
};

export default Register;
