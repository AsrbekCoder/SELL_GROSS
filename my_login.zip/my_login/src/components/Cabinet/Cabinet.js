import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router";
import { isLoginTrue, logout } from "../../redux/slices/authLogin";

const Cabinet = () => {
  const dispatch = useDispatch();
  const { status } = useSelector(({ login }) => login);

  let isTrue = isLoginTrue(status);

  const handleLogout = () => {
    dispatch(logout());
    localStorage.removeItem("token");
  };

  if (!isTrue) {
    return <Navigate to="/" />;
  }
  return (
    <section className="cabinet">
      <button className="btn" onClick={handleLogout}>
        Cabinet
      </button>
    </section>
  );
};

export default Cabinet;
