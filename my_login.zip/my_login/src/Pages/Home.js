import { faHeart } from "@fortawesome/free-regular-svg-icons";
import { faCartShopping } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import Slides from "../components/Slides/Slides";
import SlidesCategories from "../components/Slides/SlidesCategories";

const Home = () => {
  return (
    <>
      <Slides />
      <SlidesCategories />

      <div className="cart_container">
        <div className="cart_box">
          <div className="cart_item">
            <div className="cart_news">
              <div className="cart_type">Super</div>
              <div className="cart_prise_pres">cheep 52%</div>
            </div>
            <div className="cart_header">
              <img
                src="https://ikarvon.uz/storage/products/January2022/31908/783-1-small.jpg"
                alt=""
              />
            </div>
            <div className="cart_diskreption">
              Лицевая панель для выключателей двойная Legrand Valena Allure
              жемчуг
            </div>
            <div className="cart_prise">1 141 130 so'm</div>
            <div className="cart_buttons">
              <button className="add_to_cart">
                <FontAwesomeIcon icon={faCartShopping} />
              </button>
              <button className="add_to_save">
                <FontAwesomeIcon icon={faHeart} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
