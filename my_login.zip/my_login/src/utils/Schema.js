import * as yup from "yup";

export const registerSchema = yup.object().shape({
  firstname: yup
    .string()
    .required("First name is required")
    .max(15, "Name must be at most 10 character"),
  secondname: yup
    .string()
    .required("Second name is required")
    .max(10, "Secon Name must be at most 10 character"),
  phonenumber: yup.string().required("Phone Number is required").min(4),
  password: yup.string().required("Password is required").min(8),
  passwordConfirm: yup
    .string()
    .required("Confirm Password is required")
    .oneOf([yup.ref("password")], "Password doest match"),
});
export const loginSchema = yup.object().shape({
  phonenumber: yup.string().required("Phone Number is required").min(4),
  password: yup.string().required("Password is required").min(8),
});
